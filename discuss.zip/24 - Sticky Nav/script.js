const nav = document.querySelector('#main')
const top = nav.offsetTop

function naviGation() {
    if (window.scrollY >= top ){
        document.body.style.paddingTop = nav.offsetHeight + 'px';
        document.body.classList.add('fixed-nav');
      } else {
        document.body.classList.remove('fixed-nav');
        document.body.style.paddingTop = 0;
      }
}

window.addEventListener('scroll',naviGation)